package server

import (
	"context"
	"log"
	"time"

	"minicloud/internal/admin"
	"minicloud/internal/auth"
	"minicloud/internal/chat"
	"minicloud/internal/config"
	"minicloud/internal/dialogue"
	"minicloud/internal/funcs"
	"minicloud/internal/hooks"
	"minicloud/internal/leaderboard"
	"minicloud/internal/logs"
	"minicloud/internal/oauth"
	"minicloud/internal/player"
	"minicloud/internal/ratelimit"
	"minicloud/internal/realtime"
	"minicloud/internal/repo"
	"minicloud/internal/sso"
	"minicloud/internal/stats"
	"minicloud/internal/storage"
	"minicloud/internal/store"
	"minicloud/internal/updates"
)

// deps holds everything the route table needs. Building it is kept separate
// from wiring routes so each stays readable on its own.
type deps struct {
	blob  storage.Storage
	store *store.Store // readiness probes ping the dependencies directly

	limiter ratelimit.Limiter
	logs    *logs.Service
	hub     *realtime.Hub

	authH     *auth.Handler
	ssoH      *sso.Handler
	oauthH    *oauth.Handler
	playerH   *player.Handler
	lbH       *leaderboard.Handler
	dialogueH *dialogue.Handler
	chatH     *chat.Handler
	fnH       *funcs.Handler
	updatesH  *updates.Handler
	adminH    *admin.Handler
	hooksH    *hooks.Handler
	logsH     *logs.Handler
	statsH    *stats.Handler
	healthH   *stats.HealthHandler
}

// newDeps constructs the services and starts the background workers. Every
// worker is bound to ctx, so they stop when the server does.
func newDeps(ctx context.Context, cfg config.Config, st *store.Store, blob storage.Storage) *deps {
	games := repo.Games{DB: st.DB}
	players := repo.Players{DB: st.DB}
	data := repo.PlayerData{DB: st.DB}
	accounts := repo.Accounts{DB: st.DB}

	logSvc := logs.NewService(ctx, st.DB, cfg.LogRetentionDays)
	logSvc.StartRetention(ctx)

	bus := hooks.NewBus(repo.Webhooks{DB: st.DB}, repo.WebhookDeliveries{DB: st.DB}, cfg.FuncHTTPAllowPrivate)
	bus.Logs = logSvc

	statsLoc, err := time.LoadLocation(cfg.StatsTZ)
	if err != nil {
		log.Printf("stats: unknown timezone %q, falling back to UTC", cfg.StatsTZ)
		statsLoc = time.UTC
	}
	statsSvc := &stats.Service{RDB: st.RDB, DB: st.DB, Games: games, Loc: statsLoc}
	statsSvc.StartAggregator(ctx)

	limiter := ratelimit.Limiter{RDB: st.RDB, TrustProxy: cfg.TrustProxy}
	attempts := ratelimit.NewAttempts(st.RDB)

	issuer := auth.NewTokenIssuer(cfg.JWTSecret, cfg.TokenTTL)
	tickets := sso.Tickets{RDB: st.RDB}
	passwordProvider := auth.PasswordProvider{Players: players}
	ssoProvider := sso.Provider{Accounts: accounts, Players: players, Tickets: tickets}

	chatSvc := chat.NewService(repo.Chat{DB: st.DB}, cfg.BannedWordsFile)
	hub := realtime.NewHub(chatSvc, issuer)

	lbSvc := &leaderboard.Service{RDB: st.RDB, Scores: repo.Scores{DB: st.DB}, Players: players}
	fnRuntime := &funcs.Runtime{
		GameData: repo.GameData{DB: st.DB}, PlayerData: data, Players: players, Games: games,
		Leaderboard: lbSvc, AllowPrivateHTTP: cfg.FuncHTTPAllowPrivate, Logs: logSvc,
	}
	fnHandler := &funcs.Handler{
		Functions: repo.Functions{DB: st.DB}, Games: games, Players: players,
		Runtime: fnRuntime, Logs: logSvc,
	}
	(&funcs.Scheduler{Functions: fnHandler.Functions, Runtime: fnRuntime, Logs: logSvc}).Start(ctx)

	return &deps{
		blob:    blob,
		store:   st,
		limiter: limiter,
		logs:    logSvc,
		hub:     hub,
		authH: &auth.Handler{
			Issuer:   issuer,
			Registry: auth.NewRegistry(auth.GuestProvider{Players: players}, passwordProvider, ssoProvider),
			Games:    games, Players: players, Password: passwordProvider,
			Events: bus, Stats: statsSvc, Attempts: attempts,
		},
		ssoH: &sso.Handler{
			Issuer: issuer, Accounts: accounts, Players: players, Games: games,
			Tickets: tickets, Attempts: attempts,
		},
		oauthH: &oauth.Handler{
			Issuer: issuer, RDB: st.RDB, Accounts: accounts,
			Clients: repo.OAuthClients{DB: st.DB}, Grants: repo.OAuthGrants{DB: st.DB},
			RefreshTokens: repo.OAuthRefreshTokens{DB: st.DB},
		},
		playerH:   &player.Handler{Players: players, Data: data},
		lbH:       &leaderboard.Handler{Svc: lbSvc, Events: bus},
		dialogueH: &dialogue.Handler{Dialogues: repo.Dialogues{DB: st.DB}},
		chatH:     &chat.Handler{Svc: chatSvc},
		fnH:       fnHandler,
		updatesH: &updates.Handler{
			Games: games, Releases: repo.Releases{DB: st.DB}, Artifacts: repo.Artifacts{DB: st.DB},
			Storage: blob, MaxArtifactSize: cfg.MaxArtifactSize, Events: bus,
		},
		adminH: &admin.Handler{
			Issuer: issuer, User: cfg.AdminUser, Pass: cfg.AdminPass,
			Games: games, Players: players, Accounts: accounts, Data: data,
			Dialogues: repo.Dialogues{DB: st.DB}, OAuthClients: repo.OAuthClients{DB: st.DB}, Hub: hub,
			DefaultJWTSecret: cfg.JWTSecret == config.DefaultJWTSecret,
		},
		hooksH:  &hooks.Handler{Bus: bus},
		logsH:   &logs.Handler{Svc: logSvc},
		statsH:  &stats.Handler{Svc: statsSvc, Online: hub.OnlineCount},
		healthH: &stats.HealthHandler{Svc: statsSvc, StartedAt: time.Now(), Version: Version, Env: cfg.Env},
	}
}
