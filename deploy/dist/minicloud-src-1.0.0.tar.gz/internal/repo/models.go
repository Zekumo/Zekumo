package repo

import (
	"encoding/json"
	"time"
)

type Game struct {
	ID        string    `json:"id"`
	AppID     string    `json:"app_id"`
	AppSecret string    `json:"app_secret,omitempty"`
	Name      string    `json:"name"`
	Status    string    `json:"status"`
	CreatedAt time.Time `json:"created_at"`

	// SSORedirectURLs is a newline-separated list of allowed redirect URL
	// prefixes for the hosted SSO authorize page.
	SSORedirectURLs string `json:"sso_redirect_urls"`

	// FuncHTTPAllowlist is a newline-separated list of hosts (exact, or
	// *.suffix) that this game's cloud functions may fetch.
	FuncHTTPAllowlist string `json:"func_http_allowlist"`
}

type Player struct {
	ID          string          `json:"id"`
	GameID      string          `json:"game_id"`
	Provider    string          `json:"provider"`
	Identifier  string          `json:"identifier"`
	Nickname    string          `json:"nickname"`
	Profile     json.RawMessage `json:"profile"`
	Banned      bool            `json:"banned"`
	AccountID   *string         `json:"account_id,omitempty"`
	CreatedAt   time.Time       `json:"created_at"`
	LastLoginAt time.Time       `json:"last_login_at"`

	PasswordHash string `json:"-"`
}

// Account is a platform-wide identity (MiniCloud 通行证).
type Account struct {
	ID          string    `json:"id"`
	Username    string    `json:"username"`
	Nickname    string    `json:"nickname"`
	CreatedAt   time.Time `json:"created_at"`
	LastLoginAt time.Time `json:"last_login_at"`

	PasswordHash string `json:"-"`
}

// LinkedPlayer is a per-game player attached to an account.
type LinkedPlayer struct {
	GameID   string `json:"game_id"`
	GameName string `json:"game_name"`
	PlayerID string `json:"player_id"`
	Nickname string `json:"nickname"`
}

type DataEntry struct {
	Key       string          `json:"key"`
	Value     json.RawMessage `json:"value,omitempty"`
	UpdatedAt time.Time       `json:"updated_at"`
}

type DialogueScript struct {
	ID        string          `json:"id"`
	GameID    string          `json:"game_id"`
	ScriptKey string          `json:"script_key"`
	Title     string          `json:"title"`
	Content   json.RawMessage `json:"content,omitempty"`
	Version   int             `json:"version"`
	UpdatedAt time.Time       `json:"updated_at"`
}

type Release struct {
	ID                  int64      `json:"id"`
	GameID              string     `json:"game_id"`
	Channel             string     `json:"channel"`
	Version             string     `json:"version"`
	Changelog           string     `json:"changelog"`
	Status              string     `json:"status"`
	Mandatory           bool       `json:"mandatory"`
	MinSupportedVersion string     `json:"min_supported_version,omitempty"`
	RolloutPercent      int        `json:"rollout_percent"`
	PublishedAt         *time.Time `json:"published_at,omitempty"`
	CreatedAt           time.Time  `json:"created_at"`
}

type Artifact struct {
	ID         int64     `json:"id"`
	ReleaseID  int64     `json:"release_id"`
	Platform   string    `json:"platform"`
	Arch       string    `json:"arch"`
	Filename   string    `json:"filename"`
	Size       int64     `json:"size"`
	StorageKey string    `json:"-"`
	SHA256     string    `json:"sha256"`
	Status     string    `json:"status"`
	CreatedAt  time.Time `json:"created_at"`
}

type ChatMessage struct {
	ID         int64     `json:"id"`
	GameID     string    `json:"game_id"`
	Channel    string    `json:"channel"`
	SenderID   string    `json:"sender_id"`
	SenderName string    `json:"sender_name"`
	Content    string    `json:"content"`
	CreatedAt  time.Time `json:"created_at"`
}
